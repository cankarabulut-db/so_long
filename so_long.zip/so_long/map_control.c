#include "so_long.h"

int countline(int fd)
{
	char *str;
	int i;

	i = 0;
	str = get_next_line(fd);
	if (str != NULL)
	{
		i++;
		i += countline(fd);
	}
	free(str);
	return (i);
}

char **get_map(char *str, t_solong *solong)
{
	char **ret;
	int a;
	int b;

	a = open(str,O_RDONLY);
	solong->mapy = countline(a);
	ret = malloc(sizeof(char *) * (solong->mapy + 1));
	if (!ret)
		return (NULL);
	close(a);
	open(str,O_RDONLY);
	b = -1;
	while (++b < solong->mapy)
		ret[b] = get_next_line(a);
	ret[b] = NULL;
	return (ret);
}

int main()
{
	t_solong solong;

	solong.map = get_map("a.ber",&solong);
	for (int x = 0; x < solong.mapy; x ++)
		printf("%s",solong.map[x]);
}