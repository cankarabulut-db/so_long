#ifndef SO_LONG_H
#define SO_LONG_H


#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include "getnextline/get_next_line.h"
#include "mlx/mlx.h"

typedef struct s_solong{

	char **map;
	char **mapcopy;
	char *mapname;
	int mapy;
	int mapx;
	int chrx;
	int chry;
	int		p_count;
	int 	c_count;
	int 	e_count;
	int		w_count;
	void	*player;
	void	*wall;
	void	*floor;
	void	*exit;
	void 	*coll;
	void *mlx;
	void *mlx_win;
}				t_solong;

typedef struct s_point
{
	int	x;
	int	y;
}	t_point;


int ft_strchr(char *str,char c);
void errorm(t_solong *main,char x);
void map_verify(t_solong *map_check,char *ber,int j,int i);
void map_verify_1(t_solong *map_check,int a,int i);
void map_verify_2(t_solong *map_check,int x,int i);
char **get_map(char *str, t_solong *solong);
int countline(int fd);
void free_map(t_solong *solong,int a);
void flood_fill_check(t_solong *solong,int y,int x);
void deflood(t_solong *solong);
void flood_fill(t_solong *solong,int i);
void	f_fill(char **tab, t_point map_size, int y, int x);
int		ft_move(int keycode, t_solong *solong);
//void upload_img(t_solong *solong);
//void	putwindow(t_solong *solong, int x, int y);
void map_name_checker(char *str,int i);



#endif