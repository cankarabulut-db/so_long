#include "so_long.h"
void free_map(t_solong *solong,int a)
{
	int i;

	i = -1;
	if(a == 1)
	{
		while(solong->mapy > ++i)
			free(solong->mapcopy[i]);
		free(solong->mapcopy);
	}
	else
	{
		while(solong->mapy > ++i)
			free(solong->map[i]);
		free(solong->map);
	}
}
void errorm(t_solong *main,char x)
{
	if(x == 'm')
		printf("Something is wrong between the first and last line!");
	else if(x == 'a')
		printf("Unwanted Character on the map!");
	else if(x == 'e')
		printf("The lines are not equal!");
	else if(x == 's')
		printf("Something is wrong on the wall!");
	else if(x == 'w')
		printf("There are too many exits or players.");
	else if(x == 'f')
		{
			printf("Flood Fill Error!");
			free_map(main,1);
		}
	else if(x == 't')
		{
			printf("Error");
			free_map(main,2);
		}
	else if(x == 'x')
		printf("Map is enormous!");
	exit(1);
}