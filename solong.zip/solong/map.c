/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   map.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nkarabul <nkarabul@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/19 23:47:42 by nkarabul          #+#    #+#             */
/*   Updated: 2024/02/20 18:39:40 by nkarabul         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

int	countline(int fd)
{
	char	*str;
	int		i;

	i = 0;
	str = get_next_line(fd);
	if (str != NULL)
	{
		i++;
		i += countline(fd);
	}
	free(str);
	return (i);
}

char	**get_map(char *str, t_solong *solong)
{
	char	**ret;
	int		fd;
	int		b;

	fd = open(str, O_RDONLY);
	if (fd == -1)
	{
		ft_printf("That file is not openable.");
		exit(1);
	}
	solong->mapy = countline(fd);
	ret = malloc(sizeof(char *) * (solong->mapy + 1));
	if (!ret)
		return (NULL);
	close(fd);
	fd = open(str, O_RDONLY);
	b = -1;
	while (++b < solong->mapy)
		ret[b] = get_next_line(fd);
	ret[b] = NULL;
	solong->mapx = ft_strlen(ret[0]);
	return (ret);
}
