/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   map_control2.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nkarabul <nkarabul@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/20 00:03:06 by nkarabul          #+#    #+#             */
/*   Updated: 2024/02/20 18:47:58 by nkarabul         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

int	ft_strchr(char *str, char c)
{
	int	i;

	i = 0;
	while (str[i])
	{
		if (str[i] == c)
			return (1);
		i++;
	}
	return (0);
}

void	deflood(t_solong *solong)
{
	t_point	map;
	t_point	character;

	map.x = solong->mapx;
	map.y = solong->mapy;
	character.x = solong->chrx;
	character.y = solong->chry;
	f_fill(solong->mapcopy, map, character.y, character.x);
}

void	flood_fill_check(t_solong *solong, int y, int x)
{
	y = 0;
	while (solong->mapcopy[y])
	{
		x = 0;
		while (solong->mapcopy[y][x])
		{
			if (ft_strchr("PEC", solong->mapcopy[y][x]))
				errorm(solong, 'f');
			x++;
		}
		y++;
	}
}

void	flood_fill(t_solong *solong, int i)
{
	int	fd;

	fd = open(solong->mapname, O_RDONLY);
	solong->mapcopy = malloc(sizeof(char *) * (solong->mapy + 1));
	while (solong->mapy > ++i)
		solong->mapcopy[i] = get_next_line(fd);
	solong->mapcopy[i] = NULL;
	deflood(solong);
	flood_fill_check(solong, 0, 0);
	free_map(solong, 1);
}
