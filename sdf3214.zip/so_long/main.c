#include "so_long.h"
void map_name_checker(char *str,int i)
{
	i = ft_strlen(str) - 1;
	if (str[i] != 'r' || str[i - 1] != 'e' || str[i - 2] != 'b' \
	|| str[i - 3] != '.')
	{
		printf("Map name Error!");
		exit(1);
	}
}

void upload_img(t_solong *so_long)
{
	int i;
	int x;

}

int main(int ac,char **av)
{
	t_solong so_long;

	if(ac != 2)
	{
		printf("Argument Error.\nTry this : ./a.out <mapLocation> ");
		exit(1);
	}
	so_long.mapname = av[1];
	map_name_checker(so_long.mapname,0);
	map_verify(&so_long,so_long.mapname,0,0);
	flood_fill(&so_long,0,-1);
	so_long.mlx=mlx_init();
	// mlx_xpm_file_to_image();
	so_long.mlx_win= mlx_new_window(so_long.mlx,500,500,"Solong");
	//mlx_put_image_to_window();
	mlx_loop(so_long.mlx);
}