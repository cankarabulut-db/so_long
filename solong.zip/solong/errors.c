/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   errors.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nkarabul <nkarabul@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/20 00:01:30 by nkarabul          #+#    #+#             */
/*   Updated: 2024/02/20 18:26:34 by nkarabul         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

void	free_map(t_solong *solong, int a)
{
	int	i;

	i = -1;
	if (a == 1)
	{
		while (solong->mapy > ++i)
			free(solong->mapcopy[i]);
		free(solong->mapcopy);
	}
	else
	{
		while (solong->mapy > ++i)
			free(solong->map[i]);
		free(solong->map);
	}
}

void	errorm(t_solong *main, char x)
{
	if (x == 'm')
		ft_printf("Map Error!");
	else if (x == 'f')
	{
		ft_printf("Flood Fill Error!");
		free_map(main, 1);
	}
	else if (x == 't')
	{
		ft_printf("Error");
		free_map(main, 2);
	}
	else if (x == 'd')
	{
		ft_printf("Congratulations you collected all the roses!");
		free_map(main, 2);
	}
	exit(1);
}

void	close_game(t_solong *main)
{
	free_map(main, 2);
	ft_printf("Game closed");
	exit(1);
}
