#include "so_long.h"
void map_name_checker(char *str,int i)
{
	i = ft_strlen(str) - 1;
	if (str[i] != 'r' || str[i - 1] != 'e' || str[i - 2] != 'b' \
	|| str[i - 3] != '.')
	{
		printf("Map name Error!");
		exit(1);
	}
}

void uploadimg(t_solong *so_long)
{
	int a;
	int b;

	so_long->player = mlx_xpm_file_to_image(so_long->mlx,"textures/p.xpm",&a,&b);
	so_long->floor = mlx_xpm_file_to_image(so_long->mlx,"textures/floor.xpm",&a,&b);
	so_long->wall = mlx_xpm_file_to_image(so_long->mlx,"textures/wall.xpm",&a,&b);
	so_long->coll = mlx_xpm_file_to_image(so_long->mlx,"textures/coll.xpm",&a,&b);
	so_long->exit = mlx_xpm_file_to_image(so_long->mlx,"textures/exit.xpm",&a,&b);
	if(!so_long->player || !so_long->floor || !so_long->wall \
	|| !so_long->coll || !so_long->exit)
		errorm(so_long,'t');
	so_long->mlx_win = mlx_new_window(so_long->mlx,so_long->mapx * 64, so_long->mapy * 64,"so long");
}

void putimg(t_solong *so_long,int y,int x)
{
	while(so_long->mapy > y)
	{
		x = 0;
		while(so_long->mapx > x)
		{
			if(so_long->map[y][x] == '1')
				mlx_put_image_to_window(so_long->mlx,so_long->mlx_win
				,so_long->wall,x * 64,y * 64);
			if(so_long->map[y][x] == '0')
				mlx_put_image_to_window(so_long->mlx,so_long->mlx_win
				,so_long->floor,x * 64,y * 64);
			if(so_long->map[y][x] == 'P')
				mlx_put_image_to_window(so_long->mlx,so_long->mlx_win
				,so_long->player,x * 64,y * 64);
			if(so_long->map[y][x] == 'C')
			mlx_put_image_to_window(so_long->mlx,so_long->mlx_win
				,so_long->coll,x * 64,y * 64);
			if(so_long->map[y][x] == 'E')
				mlx_put_image_to_window(so_long->mlx,so_long->mlx_win
				,so_long->exit,x * 64,y * 64);
			x++;
		}
		y++;
	}
}

int		ft_move(int keycode, t_solong *solong)
{
	printf("%d\n", keycode);
	if (keycode == 53)
	{
		printf("Game closed.");
		exit(1);
	}
	else if(keycode == 0)
	{
		solong->map[solong->chry][solong->chrx -1] = 'P';
		solong->chrx -= 1;
		putimg(solong,0,0);
	}
	//else if(keycode == 1)
	//else if(keycode == 2)
	//else if(keycode == 13)
}
int main(int ac,char **av)
{
	int a;
	int b;
	t_solong *so_long;

	so_long = malloc(sizeof(t_solong));
	if(ac != 2)
	{
		printf("Argument Error.\nTry this : ./a.out <mapLocation> ");
		exit(1);
	}
	so_long->mapname = av[1];
	map_name_checker(so_long->mapname,0);
	map_verify(so_long,so_long->mapname,0,0);
	flood_fill(so_long,-1);
	so_long->mlx = mlx_init();
	uploadimg(so_long);
	putimg(so_long,0,0);
	mlx_key_hook(so_long->mlx_win,ft_move,so_long);
	mlx_loop(so_long->mlx);
}