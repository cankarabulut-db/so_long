/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   so_long.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nkarabul <nkarabul@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/19 23:58:46 by nkarabul          #+#    #+#             */
/*   Updated: 2024/02/20 18:47:40 by nkarabul         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SO_LONG_H
# define SO_LONG_H

# include <fcntl.h>
# include "getnextline/get_next_line.h"
# include "ft_printf/ft_printf.h"
# include "mlx/mlx.h"

typedef struct s_solong
{
	char	**map;
	char	**mapcopy;
	char	*mapname;
	int		mapy;
	int		mapx;
	int		chrx;
	int		chry;
	int		exit_x;
	int		exit_y;
	int		p_count;
	int		c_count;
	int		c_collected;
	int		e_count;
	int		w_count;
	void	*player;
	void	*wall;
	void	*floor;
	void	*exit;
	void	*coll;
	void	*mlx;
	void	*mlx_win;
}				t_solong;

typedef struct s_point
{
	int	x;
	int	y;
}	t_point;

char	**get_map(char *str, t_solong *solong);
int		countline(int fd);
int		ft_key(int keycode, t_solong *solong);
int		ft_strchr(char *str, char c);
void	map_name_checker(char *str, int i);
void	ft_close(t_solong *solong);
void	ft_left(t_solong *solong);
void	ft_right(t_solong *solong);
void	ft_up(t_solong *solong);
void	ft_down(t_solong *solong);
void	putimg(t_solong *so_long, int y, int x);
void	close_game(t_solong *main);
void	free_map(t_solong *solong, int a);
void	flood_fill_check(t_solong *solong, int y, int x);
void	deflood(t_solong *solong);
void	flood_fill(t_solong *solong, int i);
void	f_fill(char **tab, t_point map_size, int y, int x);
void	errorm(t_solong *main, char x);
void	map_verify(t_solong *map_check, char *ber, int j, int i);
void	map_verify_1(t_solong *map_check, int a, int i);
void	map_verify_2(t_solong *map_check, int x, int i);

#endif