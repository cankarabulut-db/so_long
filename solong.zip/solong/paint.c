/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   paint.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nkarabul <nkarabul@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/02/19 23:45:33 by nkarabul          #+#    #+#             */
/*   Updated: 2024/02/20 18:26:10 by nkarabul         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

void	ft_close(t_solong *solong)
{
	ft_printf("Game closed.");
	free_map(solong, 2);
	exit(1);
}

void	ft_left(t_solong *solong)
{
	if (solong->map[solong->chry][solong->chrx - 1] != '1')
	{
		if (solong->map[solong->chry][solong->chrx - 1] == 'C')
			solong->c_collected++;
		solong->w_count++;
		ft_printf("Move count :%d\n", solong->w_count);
		if (solong->map[solong->chry][solong->chrx - 1] == 'E')
		{
			if (solong->c_collected == solong->c_count)
				errorm(solong, 'd');
			solong->map[solong->chry][solong->chrx] = '0';
			solong->chrx--;
			solong->map[solong->chry][solong->chrx] = 'P';
			return ;
		}
		solong->map[solong->chry][solong->chrx] = '0';
		solong->chrx--;
		solong->map[solong->chry][solong->chrx] = 'P';
	}
	if (solong->map[solong->exit_y][solong->exit_x] != 'E')
		solong->map[solong->exit_y][solong->exit_x] = 'E';
}

void	ft_right(t_solong *solong)
{
	if (solong->map[solong->chry][solong->chrx + 1] != '1')
	{
		if (solong->map[solong->chry][solong->chrx + 1] == 'C')
			solong->c_collected++;
		solong->w_count++;
		if (solong->map[solong->chry][solong->chrx + 1] == 'E')
		{
			if (solong->c_collected == solong->c_count)
				errorm(solong, 'd');
			solong->map[solong->chry][solong->chrx] = '0';
			solong->chrx++;
			solong->map[solong->chry][solong->chrx] = 'P';
			return ;
		}
		ft_printf("Move count :%d\n", solong->w_count);
		solong->map[solong->chry][solong->chrx] = '0';
		solong->chrx++;
		solong->map[solong->chry][solong->chrx] = 'P';
	}
	if (solong->map[solong->exit_y][solong->exit_x] != 'E')
		solong->map[solong->exit_y][solong->exit_x] = 'E';
}

void	ft_up(t_solong *solong)
{
	if (solong->map[solong->chry - 1][solong->chrx] != '1')
	{
		if (solong->map[solong->chry - 1][solong->chrx] == 'C')
			solong->c_collected++;
		solong->w_count++;
		if (solong->map[solong->chry - 1][solong->chrx] == 'E')
		{
			if (solong->c_collected == solong->c_count)
				errorm(solong, 'd');
			solong->map[solong->chry][solong->chrx] = '0';
			solong->chry--;
			solong->map[solong->chry][solong->chrx] = 'P';
			return ;
		}
		ft_printf("Move count :%d\n", solong->w_count);
		solong->map[solong->chry][solong->chrx] = '0';
		solong->chry--;
		solong->map[solong->chry][solong->chrx] = 'P';
	}
	if (solong->map[solong->exit_y][solong->exit_x] != 'E')
		solong->map[solong->exit_y][solong->exit_x] = 'E';
}

void	ft_down(t_solong *solong)
{
	if (solong->map[solong->chry + 1][solong->chrx] != '1')
	{
		if (solong->map[solong->chry + 1][solong->chrx] == 'C')
			solong->c_collected++;
		solong->w_count++;
		if (solong->map[solong->chry + 1][solong->chrx] == 'E')
		{
			if (solong->c_collected == solong->c_count)
				errorm(solong, 'd');
			solong->map[solong->chry][solong->chrx] = '0';
			solong->chry++;
			solong->map[solong->chry][solong->chrx] = 'P';
			return ;
		}
		ft_printf("Move count :%d\n", solong->w_count);
		solong->map[solong->chry][solong->chrx] = '0';
		solong->chry++;
		solong->map[solong->chry][solong->chrx] = 'P';
	}
	if (solong->map[solong->exit_y][solong->exit_x] != 'E')
		solong->map[solong->exit_y][solong->exit_x] = 'E';
}
